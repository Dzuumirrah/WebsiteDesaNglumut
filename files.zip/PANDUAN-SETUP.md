# Panduan Setup & Penggunaan Admin Panel
## Desa Wisata Nglumut — Decap CMS

---

## BAGIAN A — Untuk Developer (Setup Sekali)

### Langkah 1: Salin file ke repository

Salin seluruh isi folder output ini ke root repository kamu dengan struktur berikut:

```
repo-root/
├── public/
│   └── admin/
│       ├── index.html      ← dari: admin/index.html
│       └── config.yml      ← dari: admin/config.yml
├── _data/
│   ├── galeri/             ← 6 file .md (slot galeri)
│   ├── hero/               ← 3 file .md (slide hero)
│   ├── fasilitas/          ← 5 file .md (kartu fasilitas)
│   ├── sejarah/            ← 3 file .md (foto sejarah)
│   └── pengaturan/
│       └── kontak.json     ← info kontak & jam buka
└── assets/
    └── uploads/            ← buat folder kosong ini (foto stakeholder masuk ke sini)
```

> **Catatan:** Buat file `.gitkeep` kosong di `assets/uploads/` agar folder
> ikut ter-commit ke Git meski masih kosong.

---

### Langkah 2: Aktifkan Netlify Identity

1. Buka **dashboard Netlify** → pilih site Nglumut
2. Klik tab **"Identity"** di menu atas
3. Klik tombol **"Enable Identity"**
4. Scroll ke bawah → **"Registration"** → pilih **"Invite only"**
   (agar hanya stakeholder yang diundang bisa login, bukan publik)

---

### Langkah 3: Aktifkan Git Gateway

1. Masih di dashboard Netlify → klik tab **"Integrations"**
2. Cari **"Git Gateway"** → klik **"Enable Git Gateway"**

Git Gateway adalah jembatan antara Decap CMS dan repository GitHub kamu.
Stakeholder tidak perlu punya akun GitHub.

---

### Langkah 4: Undang stakeholder

1. Di Netlify → **Identity** → klik **"Invite users"**
2. Masukkan email stakeholder → klik **"Send"**
3. Stakeholder akan terima email undangan → mereka klik link → set password
4. Selesai — mereka bisa login ke `/admin`

---

### Langkah 5: Verifikasi

Setelah deploy, buka: `https://desawisata-nglumut.netlify.app/admin`

Kamu akan melihat halaman login. Login dengan akun yang sudah diundang.
Pastikan 5 menu ini muncul di sidebar kiri:
- 🖼️ Galeri Foto
- 🏔️ Foto Hero (Banner Utama)
- 🎯 Foto Fasilitas & Wahana
- 📜 Foto Sejarah Desa
- ⚙️ Pengaturan Umum

---

## BAGIAN B — Untuk Stakeholder (Panduan Harian)

### Cara masuk ke panel admin

1. Buka browser (Chrome / Firefox)
2. Ketik alamat: `https://desawisata-nglumut.netlify.app/admin`
3. Masukkan email dan password yang sudah diterima dari undangan
4. Klik **"Log in"**

---

### Cara mengganti foto galeri

1. Klik menu **"🖼️ Galeri Foto"** di sidebar kiri
2. Pilih slot yang ingin diganti (contoh: "Slot 1 — Foto Galeri 1")
3. Klik tombol foto yang ada → klik **"Remove"** → klik **"Choose an image"**
4. Klik **"Upload"** → pilih foto dari komputer kamu
5. Klik **"Choose selected"**
6. Ubah **Judul Foto** dan **Keterangan** jika perlu
7. Klik tombol **"Save"** (pojok kanan atas)
8. Tunggu sekitar **1–2 menit** → website otomatis update

> ⚠️ **Tips foto:** Gunakan foto horizontal (landscape), ukuran file
> maksimal 5MB, format JPG atau PNG.

---

### Cara mengganti foto fasilitas

1. Klik menu **"🎯 Foto Fasilitas & Wahana"**
2. Pilih fasilitas yang ingin diganti fotonya
   (contoh: "1. View Sabo Dam")
3. Scroll ke bawah → temukan **"Foto 1 (Utama)"**, **"Foto 2"**, **"Foto 3"**
4. Ganti foto yang diinginkan dengan cara yang sama seperti galeri
5. Kamu juga bisa ubah **Nama Fasilitas** dan **Deskripsi Singkat**
6. Klik **"Save"** → tunggu 1–2 menit

---

### Cara mengganti foto banner utama (hero)

1. Klik menu **"🏔️ Foto Hero (Banner Utama)"**
2. Pilih slide yang ingin diganti (Slide 1, 2, atau 3)
3. Ganti foto → klik **"Save"**

> Gunakan foto beresolusi tinggi (minimal 1920×1080px) untuk hasil
> terbaik di layar lebar.

---

### Cara update nomor WhatsApp atau jam buka

1. Klik menu **"⚙️ Pengaturan Umum"**
2. Klik **"Info Kontak & Jam Buka"**
3. Ubah nomor atau jam sesuai kebutuhan
4. Klik **"Save"**

---

### Pertanyaan umum

**Website tidak update setelah saya save?**
Tunggu 2–3 menit, lalu refresh halaman website. Netlify perlu waktu
sebentar untuk rebuild otomatis.

**Saya tidak bisa login?**
Pastikan email yang digunakan sama persis dengan yang diundang.
Hubungi developer jika masih bermasalah.

**Apakah perubahan saya bisa dibatalkan?**
Ya. Semua perubahan tersimpan di Git — developer bisa rollback
ke versi sebelumnya kapan saja.

---

*Panduan ini dibuat untuk Desa Wisata Nglumut — Tim KKN 2025*
